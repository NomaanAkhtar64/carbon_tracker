// Cloud
#define serverURL "http://www.carbontrackerkarachi.live"
#define addReadingURL serverURL "/api/readings/"
#define loginURL serverURL "/login/"
#define loginInfo                                                              \
  "{\"username\": \"data_logger_1\",\"password\": "                            \
  "\"C5j85Az$QLP9ZJFr3u%nFM*b\"}"

// Wifi Credentials
// char ssid[] = "Storm F1";
// char ssid[] = "CONNECT NET 1048/F";
// char password[] = "Wrong password";
char ssid[] = "216 fiber2home 2.4 GHz";
char password[] = "10203040";
