D:\Projects\carbon_tracker\data_logger_esp8266\esp-build\core\core_esp8266_vm.cpp.o: \
 C:\Users\nomaa\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.1.2\cores\esp8266\core_esp8266_vm.cpp \
 C:\Users\nomaa\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.1.2\cores\esp8266\CommonHFile.h \
 D:\Projects\carbon_tracker\data_logger_esp8266\esp-build\core\data_logger_esp8266.ino.globals.h
