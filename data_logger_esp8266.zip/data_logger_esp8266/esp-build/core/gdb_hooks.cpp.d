D:\Projects\carbon_tracker\data_logger_esp8266\esp-build\core\gdb_hooks.cpp.o: \
 C:\Users\nomaa\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.1.2\cores\esp8266\gdb_hooks.cpp \
 C:\Users\nomaa\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.1.2\cores\esp8266\CommonHFile.h \
 D:\Projects\carbon_tracker\data_logger_esp8266\esp-build\core\data_logger_esp8266.ino.globals.h \
 C:\Users\nomaa\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.1.2/tools/sdk/include/ets_sys.h \
 C:\Users\nomaa\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.1.2/tools/sdk/include/c_types.h \
 C:\Users\nomaa\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.1.2/tools/sdk/include/eagle_soc.h \
 C:\Users\nomaa\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.1.2\cores\esp8266\gdb_hooks.h
