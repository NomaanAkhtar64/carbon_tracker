#line 1 "D:\\Projects\\carbon_tracker\\data_logger_esp8266\\handleCO2Sensor.h"
#include <cmath>
#include <Arduino.h>

float getVoltage(int reading);

int getReading(int sensorPin);

int toPPM(float reading);